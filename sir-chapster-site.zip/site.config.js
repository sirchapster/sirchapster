window.SITE_CONFIG = {
  siteTitle: "Sir Chapster — Official Site",
  artistName: "Sir Chapster",
  tagline: "New single out now.",
  primaryColor: "#ff6a3d",
  hero: {
    backgroundImage: "assets/hero-placeholder.jpg",
    ctaListen: "https://on.soundcloud.com/rIqzE7nIP4aIIYpXly",
    ctaBuy: "https://on.soundcloud.com/rIqzE7nIP4aIIYpXly"
  },
  release: {
    title: "Durty Dancing",
    coverImage: "assets/release-placeholder.jpg",
    description: "Stream it everywhere.",
    listenUrl: "https://on.soundcloud.com/rIqzE7nIP4aIIYpXly",
    buyUrl: "https://on.soundcloud.com/rIqzE7nIP4aIIYpXly",
    platforms: [
      { name: "SoundCloud", url: "https://on.soundcloud.com/rIqzE7nIP4aIIYpXly" }
    ]
  },
  tracks: [
    // Using SoundCloud embed so fans can preview right on the page
    { title: "Durty Dancing", soundcloudEmbed: "https://w.soundcloud.com/player/?url=https://on.soundcloud.com/rIqzE7nIP4aIIYpXly&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&visual=true" }
  ],
  videos: [
    { title: "Durty Dancing (Official Video)", youtubeId: "uGXlwpwBA-0" }
  ],
  shows: [
    { date: "2025-09-15", city: "Brooklyn, NY", venue: "", ticketUrl: "" }
  ],
  gallery: [
    "assets/bts-1.jpg",
    "assets/bts-2.jpg",
    "assets/bts-3.jpg",
    "assets/bts-4.jpg",
    "assets/bts-5.jpg",
    "assets/bts-6.jpg"
  ],
  about: {
    bioHtml: "<p>Sir Chapster is an independent artist. Press-ready bio coming soon.</p>",
    pressKitUrl: ""
  },
  contact: {
    bookingEmail: "chapster.sir@gmail.com",
    managementEmail: "chapster.sir@gmail.com",
    newsletterUrl: "",
    social: []
  }
};