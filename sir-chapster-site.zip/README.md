
# Music Site Starter

This is a static, mobile-friendly website for a musician/artist modeled after your mockup.

## Quick start
1. Unzip the download.
2. Open **site.config.js** and replace the placeholders with your artist info (links, bio, images, dates).
3. Start a local server (examples):
   - Python: `python3 -m http.server 5500`
   - Node: `npx serve`
4. Visit `http://localhost:5500` (or the URL your server shows).

## Deploy (free, fast)
- **Netlify**: Drag-and-drop the folder into Netlify.
- **GitHub Pages**: Push to a repo and enable Pages.
- **Vercel**: `vercel` from the folder.

## Where to edit
- **site.config.js**: All content (artist name, links, tracks, videos, shows, gallery, emails).
- **assets/**: Replace images and MP3 previews with your own.
- **styles.css**: Colors, spacing, layout (uses CSS variables).
- **index.html**: Sections/structure if you want to customize further.

## Music players
- Add short MP3 previews in `assets/` and reference them in `site.config.js`.
- Or paste a SoundCloud embed URL for any track.

## Videos
- Put YouTube video IDs (the part after `watch?v=`) in `site.config.js`.

## Shows
- Add your dates in ISO format (YYYY-MM-DD). The page automatically shows upcoming dates first.

## Forms & email list
- The booking form opens a mail draft. For a real form, replace it with Mailchimp, ConvertKit, or Formspree.
- Add your email list URL to `newsletterUrl` (optional).

## E‑commerce
- Link the **Listen** and **Buy** buttons to Spotify/Bandcamp/Shopify/Gumroad/etc.
  If you need a built-in cart later, we can add Snipcart or Stripe Checkout.

— Generated 2025-08-14
