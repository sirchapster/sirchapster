
(function(){
  const cfg = window.SITE_CONFIG || {};
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));
  const safe = (s) => s || "";

  // Colors & brand
  if (cfg.primaryColor) {
    document.documentElement.style.setProperty('--accent', cfg.primaryColor);
  }

  // Basic text
  $('#logoText').textContent = cfg.artistName || 'Artist Name';
  $('#artistName').textContent = (cfg.artistName || 'Artist Name').toUpperCase();
  $('#tagline').textContent = cfg.tagline || 'New music out now.';

  // Hero image & CTAs
  const heroEl = $('#hero');
  const heroBG = (cfg.hero && cfg.hero.backgroundImage) ? `url('${cfg.hero.backgroundImage}') center/cover no-repeat fixed` : null;
  if(heroBG){
    heroEl.style.backgroundImage = 
      `radial-gradient(90% 60% at 10% 10%, rgba(255,106,61,.15), transparent 50%),
       radial-gradient(80% 60% at 90% 10%, rgba(255,106,61,.1), transparent 50%),
       ${heroBG}`;
  }
  const navCta = $('#navCta');
  const heroListen = $('#heroListen');
  const heroBuy = $('#heroBuy');
  const listenUrl = cfg.hero?.ctaListen || cfg.release?.listenUrl || '#';
  const buyUrl = cfg.hero?.ctaBuy || cfg.release?.buyUrl || '#';
  [navCta, heroListen].forEach(el => { if(el) el.href = listenUrl; });
  if(heroBuy) heroBuy.href = buyUrl;

  // Release
  $('#releaseTitle').textContent = cfg.release?.title || 'Album Title';
  $('#releaseDesc').textContent = cfg.release?.description || '';
  const cover = cfg.release?.coverImage || 'assets/release-placeholder.jpg';
  $('#releaseCover').src = cover;
  $('#releaseCoverHero').src = cover;
  $('#releaseListen').href = cfg.release?.listenUrl || '#';
  $('#releaseBuy').href = cfg.release?.buyUrl || '#';
  const platforms = cfg.release?.platforms || [];
  const platformWrap = $('#platformLinks');
  platformWrap.innerHTML = platforms.map(p => `<a class="btn" href="${p.url}" target="_blank" rel="noopener">${p.name}</a>`).join('');

  // Tracks
  const tracksWrap = $('#tracks');
  (cfg.tracks || []).forEach((t, i) => {
    const track = document.createElement('div');
    track.className = 'track';
    const title = document.createElement('div');
    title.className = 'track-title';
    title.textContent = `${t.title || 'Untitled'} ${t.duration ? `• ${t.duration}` : ''}`;
    track.appendChild(title);
    const right = document.createElement('div');
    if (t.soundcloudEmbed) {
      const iframe = document.createElement('iframe');
      iframe.src = t.soundcloudEmbed;
      iframe.loading = 'lazy';
      iframe.width = '100%';
      iframe.height = '80';
      iframe.allow = 'autoplay';
      iframe.style.border = '0';
      right.style.gridColumn = '1 / -1';
      right.appendChild(iframe);
    } else {
      const audio = document.createElement('audio');
      audio.controls = true;
      audio.preload = 'none';
      audio.src = t.audioUrl || '';
      right.appendChild(audio);
    }
    track.appendChild(right);
    tracksWrap.appendChild(track);
  });

  // Videos
  const videoGrid = $('#videoGrid');
  (cfg.videos || []).forEach(v => {
    const iframe = document.createElement('iframe');
    iframe.loading = 'lazy';
    const src = v.youtubeId ? `https://www.youtube.com/embed/${v.youtubeId}` : (v.embedUrl || '');
    iframe.src = src;
    iframe.title = v.title || 'Video';
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
    iframe.referrerPolicy = 'strict-origin-when-cross-origin';
    iframe.allowFullscreen = true;
    videoGrid.appendChild(iframe);
  });

  // Shows
  const today = new Date().toISOString().slice(0,10);
  const shows = (cfg.shows || [])
    .filter(s => s.date >= today)
    .sort((a,b) => a.date.localeCompare(b.date));
  const showsList = $('#showsList');
  if (shows.length === 0) {
    const p = document.createElement('p');
    p.className = 'small';
    p.textContent = 'No upcoming shows — check back soon.';
    showsList.appendChild(p);
  } else {
    shows.forEach(s => {
      const card = document.createElement('div');
      card.className = 'show';
      card.innerHTML = `<div class="date">${new Date(s.date).toLocaleDateString(undefined,{month:'short', day:'numeric'})}</div>
                        <div class="city">${s.city || ''}</div>
                        <div class="venue">${s.venue || ''}</div>`;
      if (s.ticketUrl) {
        const a = document.createElement('a');
        a.className = 'btn';
        a.href = s.ticketUrl;
        a.target = "_blank";
        a.rel = "noopener";
        a.textContent = 'Tickets';
        card.appendChild(a);
      }
      showsList.appendChild(card);
    });
  }

  // Gallery
  const gallery = $('#galleryGrid');
  (cfg.gallery || []).forEach(src => {
    const img = document.createElement('img');
    img.src = src;
    img.loading = 'lazy';
    img.alt = 'Behind the scenes';
    gallery.appendChild(img);
  });

  // About / Press Kit
  $('#bioHtml').innerHTML = cfg.about?.bioHtml || '';
  if (cfg.about?.pressKitUrl) $('#pressKitBtn').href = cfg.about.pressKitUrl;

  // Contact
  const bookingEmail = cfg.contact?.bookingEmail || 'booking@example.com';
  const managementEmail = cfg.contact?.managementEmail || 'management@example.com';
  $('#bookingEmail').href = `mailto:${bookingEmail}`;
  $('#bookingEmail').textContent = bookingEmail;
  $('#managementEmail').href = `mailto:${managementEmail}`;
  $('#managementEmail').textContent = managementEmail;

  const socialWrap = $('#socialLinks');
  (cfg.contact?.social || []).forEach(s => {
    const a = document.createElement('a');
    a.href = s.url;
    a.target = "_blank"; a.rel = "noopener";
    a.textContent = s.name;
    socialWrap.appendChild(a);
  });

  // Footer year
  $('#year').textContent = new Date().getFullYear();
  $('#copyrightName').textContent = cfg.artistName || 'Artist Name';

  // Booking form -> opens mailto draft
  const form = $('#bookingForm');
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = new FormData(form);
    const name = encodeURIComponent(data.get('name'));
    const email = encodeURIComponent(data.get('email'));
    const message = encodeURIComponent(data.get('message'));
    const subject = encodeURIComponent(`[Booking Inquiry] ${cfg.artistName || 'Artist'} — from ${data.get('name')}`);
    const body = encodeURIComponent(`Name: ${decodeURIComponent(name)}\nEmail: ${decodeURIComponent(email)}\n\n${decodeURIComponent(message)}`);
    window.location.href = `mailto:${bookingEmail}?subject=${subject}&body=${body}`;
  });
})();
